
  # SocialEye Web App UI Design one week draft of app

  This is a code bundle for SocialEye Web App UI Design one week draft of app. The original project is available at https://www.figma.com/design/Y0b7snav8z6XKF8daacDaf/SocialEye-Web-App-UI-Design-one-week-draft-of-app.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  